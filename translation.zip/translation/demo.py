#/usr/bin/python
# encoding:utf-8
 
import httplib
import md5
import urllib
import urlparse
import random
import sys
import os
import time
import xlrd
from xlwt import *
from xlutils.copy import copy

httpClient = None
filepath="/home/raomingqiang/Jinkens/tomcat8/webapps/myapps/uploadFile"
newfilepath_1="/home/raomingqiang/Jinkens/tomcat8/webapps/myapps/newfile"
newfilepath_2="/home/raomingqiang/Jinkens/tomcat8/webapps/newfile"
filename=""
rowss=[]
colss=[]
colss1=[]
colss2=[]
colss3=[]
colss4=[]
list_str=[]
support_list=["zh","en","yue","wyw","jp","kor","fra","spa","th","ara","ru","pt","de","it","el","nl","pl","bul","est","dan","fin","cs","rom","slo","swe","hu","cht","vie"]

reload(sys)
sys.setdefaultencoding('UTF-8')


def erro_info(erro):
    error_name = filename+"_erroinfo.txt"
    f = open(erro,'a+')
    f.write(e)
    f.close()

files = os.listdir(filepath)
f = open("/home/raomingqiang/Jinkens/Translation/file.txt",'r+')
st = f.readline()
list = st.strip(',').split(',')
#print(list)
def check_File():
    for i in range(0,len(files)):
        if files[i] not in list:
            os.system("cp %s/'%s' %s" %(filepath,files[i],newfilepath_1))
            name = str(files[i])
            f.write(name+',')
        else:
            continue
    f.close()

def get_Task():
    global filename
    files = os.listdir(newfilepath_1)
    for i in range(0,len(files)):
        if files != "" and os.path.splitext(files[i])[1]==".xls":
            name = files[i].decode("string_escape")
            filename = os.path.splitext(files[i])[0]
            path = newfilepath_1+'/'+name
            xls_Handle(path)
            rb = xlrd.open_workbook(path)
            wb = copy(rb)
            ws = wb.get_sheet(0)
            for m in range(0,len(rowss)):
                toLang = rowss[m]
		if toLang in support_list:
                    print("toLang:",toLang)
                    try:
                        if len(colss)<30:
                            q = get_q(colss)
                            try:
                                redict = translate_xml(q,toLang)
                            except Exception,e:
                                redict = {}
                            list = get_data(redict,colss)
                        elif 30<len(colss)<=60:
                            list = get_list(2,toLang)
                        elif 60<len(colss)<=90:
                            list = get_list(3,toLang)
                        elif 90<len(colss)<=120:
                            list = get_list(4,toLang)
                        else:
                            print("the cols count is too more!")
                        write_xml(list,m,ws)
                        print("%s write done !!" %toLang)
                    except Exception,e:
                        continue
                    time.sleep(2)
	        else:
		    continue
            wb.save(path)
            print("write done %s" %name)
            os.system("mv '%s' %s" %(path,newfilepath_2))
        elif files != "" and os.path.splitext(files[i])[1]==".xlsx":
            name = files[i].decode("string_escape")
            filename = os.path.splitext(files[i])[0]
            path = newfilepath_1+'/'+name
            xls_Handle(path)
            rb = xlrd.open_workbook(path)
            wb = copy(rb)
            ws = wb.get_sheet(0)
            for m in range(0,len(rowss)):
                toLang = rowss[m]
                if toLang in support_list:
                    print("toLang:",toLang)
                    try:
                        if len(colss)<30:
                            print("if 1.........")
                            q = get_q(colss)
                            try:
                                redict = translate_xml(q,toLang)
                            except Exception,e:
                                redict = {}
                            list = get_data(redict,colss)
                        elif 30<len(colss)<=60:
                            list = get_list(2,toLang)
                        elif 60<len(colss)<=90:
                            list = get_list(3,toLang)
                        elif 90<len(colss)<=120:
                            list = get_list(4,toLang)
                        else:
                            print("the cols count is too more!")
                        write_xml(list,m,ws)
                        print("%s write done !!" %toLang)
                    except Exception,e:
                        print(e)
                        continue
                    time.sleep(1)
                else:
		    continue
            wb.save(path)
            print("write done %s" %name)
            os.system("mv '%s' %s" %(path,newfilepath_2))
        else:
            print("no files or something erro!!")
    if httpClient:
        httpClient.close()

def xls_Handle(path):
    global rowss,colss,colss1,colss2,colss3,colss4,list_str
    file_name = path
    print(file_name)
    workbook=xlrd.open_workbook(file_name)
    #shxrange=workbook.sheet_names   #获取所有sheet名
    sheet = workbook.sheet_by_index(0)   #获取第一个sheet表
    #sheet=workbook.sheet_by_name("Sheet1") #根据名字获取sheet表
    nrows=sheet.nrows   #获取行数
    ncols=sheet.ncols   #获取列数
    rows = sheet.row_values(0)  #获取第1行的所有值，以列表形式存储
    cols=sheet.col_values(1)   #获取第2列的所有值，以列表形式存储
    del rows[0]
    del rows[0]
    del cols[0]
    rowss = rows
    colss = cols
    if len(colss)<30:
        print('')
    elif 30<len(colss)<=60:
        colss1 = colss[ :30]
        colss2 = colss[30: ]
    elif 60<len(colss)<=90:
        colss1 = colss[ :30]
        colss2 = colss[30:60]
        colss3 = colss[60: ]
    elif 90<len(colss)<=120:
        colss1 = colss[ :30]
        colss2 = colss[30:60]
        colss3 = colss[60:90]
        colss4 = colss[90: ]
    else:
        text = "the cols count is too more!!"
        #print(text)
        erro_info(text)
    list_str=[colss1,colss2,colss3,colss4]
def get_q(list):
    q = ""
    #print("get_q_list ........",list)
    for line in list:
        if line == "":
            q += ("......"+'\n')
        elif '\n' in line:
            strs = line.replace("\n","&")
            q += (strs+'\n')
        else:
            q += (line+'\n')
    #q = "我的\n你的\n哈哈\n周期订阅\n年订阅"
    #print("q .........",q.encode('utf-8'))
    return q


def translate_xml(q,toLang):
    appid = '20190816000327030' #你的appid
    secretKey = '_fowMNx9nz7WdJejaYFP' #你的密钥


    httpClient = None
    myurl = '/api/trans/vip/translate'
    #q = '周期性订阅将会在当前订阅期结束前24小时内自动扣费续订，如需更改或者取消，请在24小时前在账户设置的[管理订阅]处进行修改。免费试用期结束后，将会自动在您的iTunes账户中扣除订阅费用。在免费试用期内购买VIP订阅时，免费试用期中任何未使用的部分（如有提供）将失效。了解更多资讯，可查看用户使用条款和隐私政策。\n 我愿意放弃这次优惠活动，且我不需要这些酷炫的动态壁纸。\n 3日免费试用后会自动激活$79.99/年的年订阅项目 \n 你的鼓励是我们前进的动力。'
    q = str(q)
    fromLang = 'auto'
    toLang = toLang
    salt = random.randint(32768, 65536)

    sign = appid+q+str(salt)+secretKey
    m1 = md5.new()
    m1.update(sign)
    sign = m1.hexdigest()
    myurl = myurl+'?appid='+appid+'&q='+urllib.quote(q)+'&from='+fromLang+'&to='+toLang+'&salt='+str(salt)+'&sign='+sign
    #print(myurl)

    try:
        print("in to tranlation .......")
        httpClient = httplib.HTTPConnection('api.fanyi.baidu.com')
        httpClient.request('GET', myurl)
        #response是HTTPResponse对象
        response = httpClient.getresponse()
        re = str(response.read())  #显示unicode字符的字面值 .decode('unicode-escape')
        #re2 = urlparse.unquote(re)
        #print(re.decode('unicode-escape'))
        redict = eval(re)   #强制转换为字典
        print("Translation Result:",redict)
        return redict
    except Exception, e:
        #print("erro:",e)
        erro_info("translation erro:"+e)
    finally:
        print("%s translation is done!" %toLang)


def get_data(redict,co):
    liststr = []
    list = redict["trans_result"]
    #print("dict.........",str(list).decode('unicode-escape'))
    try:
        if list == []:
            for i in range(0,len(co)):
                values = "......"
                liststr.append(values.decode('unicode-escape'))
        else:
            for i in range(0,len(list)):
                values = list[i]['dst']
                liststr.append(values.decode('unicode-escape'))
                #print(liststr)
    except Exception,e:
        print(e)
        for i in range(0,len(co)):
            values = "......"
            liststr.append(values.decode('unicode-escape'))
    return liststr

def get_list(m,toLang):
    list = []
    for i in range(0,m):
        q = get_q(list_str[i])
        #print("q ...........",q)
        try:
            redict = translate_xml(q,toLang)
        except Exception,e:
            redict = {"trans_result":[]}
        #print("Q .........")
        list += get_data(redict,list_str[i])
        time.sleep(1)
    print("LIST:............",list)
    return list

def write_xml(list,m,ws):
    global colss
    #lists = str(list).decode('unicode-escape')
    for i in range(0,len(colss)):
        ws.write(i+1,m+2,list[i])
        print("write success",list[i])
        print("write success %s line" %i)



if __name__ =='__main__':
    check_File()
    get_Task()

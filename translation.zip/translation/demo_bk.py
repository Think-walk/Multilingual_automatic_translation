#/usr/bin/python
# encoding:utf-8
 
import httplib
import md5
import urllib
import urlparse
import random
import sys
import os
import time
import xlrd
from xlwt import *
from xlutils.copy import copy

filepath="/home/raomingqiang/Jinkens/tomcat8/webapps/myapps/uploadFile"
newfilepath_1="/home/raomingqiang/Jinkens/tomcat8/webapps/myapps/newfile"
newfilepath_2="/home/raomingqiang/Jinkens/tomcat8/webapps/newfile"
rowss=[]
colss=[]

reload(sys)
sys.setdefaultencoding('UTF-8')

def check_File():
    files = os.listdir(filepath)
    #print(str(files).decode("string_escape"))
    f = open("/home/raomingqiang/Jinkens/Translation/file.txt",'r+')
    count = f.readline()
    #print(str(count).decode("string_escape"))
    for i in range(0,len(files)):
        if files[i] not in count:
            os.system("cp %s/'%s' %s" %(filepath,files[i],newfilepath_1))
            f.write(files[i]+',')
        else:
            continue
    f.close()

def get_Task():
    files = os.listdir(newfilepath_1)
    for i in range(0,len(files)):
        if files != "" and os.path.splitext(files[i])[1]==".xls":
            name = files[i].decode("string_escape")
            path = newfilepath_1+'/'+name
            q = xls_Handle(path)
            rb = xlrd.open_workbook(path)
            wb = copy(rb)
            ws = wb.get_sheet(0)
            for m in range(0,len(rowss)):
                toLang = rowss[m]
                print("toLang:",toLang)
                try:
                    redict = translate_xml(q,toLang,files[i])
                    list = get_data(redict)
                    write_xml(list,m,ws)
                except Exception,e:
                    continue
                time.sleep(1)
            wb.save(path)
            print("write done %s" %name)
            os.system("mv '%s' %s" %(path,newfilepath_2))
	elif files != "" and os.path.splitext(files[i])[1]==".xlsx":
	    name = files[i].decode("string_escape")
            path = newfilepath_1+'/'+name
            q = xls_Handle(path)
            rb = xlrd.open_workbook(path)
            wb = copy(rb)
            ws = wb.get_sheet(0)
            for m in range(0,len(rowss)):
                toLang = rowss[m]
                print("toLang:",toLang)
                try:
                    redict = translate_xml(q,toLang,files[i])
                    list = get_data(redict)
                    write_xml(list,m,ws)
                except Exception,e:
                    continue
                time.sleep(1)
            wb.save(path)
            print("write done %s" %name)
            os.system("mv '%s' %s" %(path,newfilepath_2))
        else:
            print("no files or something erro!!")

def xls_Handle(path):
    global rowss,colss
    filename = path
    print(filename)
    workbook=xlrd.open_workbook(filename)
    #shxrange=workbook.sheet_names   #获取所有sheet名
    sheet = workbook.sheet_by_index(0)   #获取第一个sheet表
    #sheet=workbook.sheet_by_name("Sheet1") #根据名字获取sheet表
    nrows=sheet.nrows   #获取行数
    ncols=sheet.ncols   #获取列数
    rows = sheet.row_values(0)  #获取第1行的所有值，以列表形式存储
    cols=sheet.col_values(1)   #获取第2列的所有值，以列表形式存储
    del rows[0]
    del rows[0]
    del cols[0]
    rowss = rows
    colss = cols
    
    q = ""
    for line in colss:
        #print(line.encode('utf-8'))
        if line == "":
	    q += ("空"+'\n')
	elif '\n' in line:
            strs = line.split('\n')[0]+line.split('\n')[1]
            q += (strs+'\n')
	else:
            q += (line+'\n')
    print(q.encode('utf-8'))
    #print(type(q))
    return q


def translate_xml(q,toLang,filename):
    appid = '20190816000327030' #你的appid
    secretKey = '_fowMNx9nz7WdJejaYFP' #你的密钥


    httpClient = None
    myurl = '/api/trans/vip/translate'
    #q = '周期性订阅将会在当前订阅期结束前24小时内自动扣费续订，如需更改或者取消，请在24小时前在账户设置的[管理订阅]处进行修改。免费试用期结束后，将会自动在您的iTunes账户中扣除订阅费用。在免费试用期内购买VIP订阅时，免费试用期中任何未使用的部分（如有提供）将失效。了解更多资讯，可查看用户使用条款和隐私政策。\n 我愿意放弃这次优惠活动，且我不需要这些酷炫的动态壁纸。\n 3日免费试用后会自动激活$79.99/年的年订阅项目 \n 你的鼓励是我们前进的动力。'
    q = str(q)
    fromLang = 'auto'
    toLang = toLang
    salt = random.randint(32768, 65536)

    sign = appid+q+str(salt)+secretKey
    m1 = md5.new()
    m1.update(sign)
    sign = m1.hexdigest()
    myurl = myurl+'?appid='+appid+'&q='+urllib.quote(q)+'&from='+fromLang+'&to='+toLang+'&salt='+str(salt)+'&sign='+sign

    try:
        httpClient = httplib.HTTPConnection('api.fanyi.baidu.com')
        httpClient.request('GET', myurl)

        #response是HTTPResponse对象
        response = httpClient.getresponse()
        re = str(response.read())  #显示unicode字符的字面值 .decode('unicode-escape')
        #re2 = urlparse.unquote(re)
        redict = eval(re)   #强制转换为字典
        #print(re)
        #print(redict)
        return redict
    except Exception, e:
        error_name = filename.split('.xls')[0]+".txt"
        f = open(error_name,'w')
        f.write(e)
        f.close()
        print e
    finally:
        if httpClient:
            httpClient.close()

def get_data(redict):
    liststr = []
    list = redict["trans_result"]
    #print(str(list).decode('unicode-escape'))
    for i in range(0,len(list)):
        values = list[i]['dst']
        liststr.append(values.decode('unicode-escape'))
    print(liststr)
    return liststr

def write_xml(list,m,ws):
    global colss
    #lists = str(list).decode('unicode-escape')
    for i in range(0,len(colss)):
        ws.write(i+1,m+2,list[i])
        print("write success",list[i])
        print("write success %s line" %i)
    print("write done",m)



if __name__ =='__main__':
    check_File()
    get_Task()

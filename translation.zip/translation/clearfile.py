#/usr/bin/python
# encoding:utf-8

import os

newfilepath="/home/raomingqiang/Jinkens/tomcat8/webapps/newfile"
logpath="/home/raomingqiang/Jinkens/Translation/demo_log.txt"
os.system("rm -r %s/* %s" %(newfilepath,logpath))
